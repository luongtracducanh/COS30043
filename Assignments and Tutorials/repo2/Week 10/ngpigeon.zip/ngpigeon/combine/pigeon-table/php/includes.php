<?php

echo "
    <meta name='viewport' content='width=device-width, initial-scale=1.0'/>
    <link href='pigeon-table/css/bootstrap.min.css' rel='stylesheet' />
    <link href='pigeon-table/css/pigeon-table.css' rel='stylesheet' />
    <script src='pigeon-table/js/jquery.min.js'></script>
    <script src='pigeon-table/js/bootstrap.min.js'></script>
    <script src='pigeon-table/js/angular.min.js'></script>
    <script src='pigeon-table/js/ui-bootstrap-tpls-2.5.0.min.js'></script>
    <script src='pigeon-table/js/pigeon-table.js'></script>";

?>
