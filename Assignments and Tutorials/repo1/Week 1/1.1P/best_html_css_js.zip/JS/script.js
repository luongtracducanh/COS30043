function validateRegister() {
    var name = document.getElementById("name").value;
    var mail = document.getElementById("mail").value;
    var remail = document.getElementById("remail").value;
    var gender = document.getElementById("gender").value;
    var password = document.getElementById("password").value;
    var repass = document.getElementById("repass").value;
    var passw=  /^[A-Za-z]\w{8,}$/;
    var errmsg = "";
    var result = true;
    if (name == "") {
        errmsg += "You must enter your name.\n";
    }
    if (mail != remail) {
        errmsg += "You re-entered the wrong mail.\n";
    }
    
    if (gender == "other")
    {
        errmsg += "There are only 2 genders, so pick one or get out of our restaurant!\n"
    }

    if(! password.match(passw))
    {
        errmsg += "Password should be 8 characters or more.\n"
    }

    if (password != repass)
    {
        errmsg += "You re-entered the wrong password!\n"
    }

    if(errmsg != "") {
        alert (errmsg);
        result = false;
    }
    return result;
}
function initRegister() {
    var form = document.getElementById("form");
    form.onsubmit = validateRegister;
}
window.onload = initRegister;