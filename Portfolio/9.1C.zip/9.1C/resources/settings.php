<?php
// Config for database connection
$host = "localhost";
$username = "ducanh";
$password = "ducanh2003";
$dbname = "IDD";
